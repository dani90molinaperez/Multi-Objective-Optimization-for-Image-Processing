function [p, VFO, F, C] = SortPopulation(p,VFO,F,C)

    % Sort Based on Crowding Distance
    [~, index] = sort(C, 'descend');
    p = p(index,:);
    VFO = VFO(index,:);
    F = F(index);
    C = C(index);
    
    % Sort Based on the Front
    [~, index] = sort(F);
    p = p(index,:);
    VFO = VFO(index,:);
    F = F(index);
    C = C(index);
    
    
end