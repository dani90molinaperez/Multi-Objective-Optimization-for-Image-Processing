function [Frente]=NonDominatedSorting(VFO)

Frente=zeros(size(VFO,1),1);

%sort
for i=1:size(VFO,1)
    
    %All vectors that dominate the vector at i (strong dominance: dominates if all values are less than or equal and at least one is strictly less).
    domina=all(VFO<=VFO(i,:),2) & any(VFO<VFO(i,:),2); 
    
    Frente(i,1)=sum(domina)+1;    
end
end